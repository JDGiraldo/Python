#Juan Diego Giraldo Gomez

#Importar la clase Stack de la biblioteca lists
from lists import Stack
from os import system

#Crear una instancia (copia u objeto de la pila)
pila1 = Stack()
pila2 = Stack()

#Guardar acciones de la pila
pila1.Push(42)
pila1.Push(50)
pila1.Push(67)
pila1.Push(12)
pila1.Push(28)

pila2.Push(33)
pila2.Push(50)
pila2.Push(42)
pila2.Push(68)
pila2.Push(28)


print("Pila 1")
pila1.Show()
print("\n")
print("Pila 2")
pila2.Show()
print("\n")
print("Pila 3")

diferencia_pila1 = Stack()
diferencia_pila2 = Stack()

while not pila1.Empty():
    elemento = pila1.Pop()
    if elemento == pila2.Top():
        diferencia_pila1.Push(elemento)
while not pila2.Empty():
    elemento = pila2.Pop()
    if elemento != pila1.Top():
        diferencia_pila2.Push(elemento)

diferencia_pila1.Show()
print("")
diferencia_pila2.Show()
